import Flower1 from "../Images/flower16.jpeg";
import Flower2 from "../Images/flower15.jpeg";
import Flower3 from "../Images/nature.jpg";
import Flower4 from "../Images/flower13.jpeg";
import Flower5 from "../Images/flower12.jpeg";
import Flower6 from "../Images/flower11.webp";
import Flower7 from "../Images/flower10.jpeg";
import Flower8 from "../Images/flower9.jpg";

export const images = [
    {title:"Node JS & VS code installation", subtitle:"Mentor:Use-cmd,Me:Panicking, why terminal doesn't like me", img: Flower1},
    {title:"Arrays & Classes", subtitle:"Mentor:Constructor@10:10,Me:At 10:45, okay got it", img: Flower2},
    {title:"HTML", subtitle:"Mentor:Syntax,Me:Just now i was understanding JS", img: Flower3},
    {title:"CSS and Bootstrap", subtitle:"Mentor:Decorating webpage,Me:Why webpage needs make-up", img: Flower4},
    {title:"Advanced JavaScript", subtitle:"Mentor:Promises,Me:Code also promises,good to know", img: Flower5},
    {title:"React", subtitle:"Mentor:It's a libray not framework,Me:But i like React", img: Flower6},
    {title:"Node JS,Mongodb", subtitle:"Mentor:Relation between Client&Server,Me:Oh backend also we should do", img: Flower7},
    {title:"GIT,Deployment", subtitle:"Mentor:Very necessary,Me:We can store code in Drive", img: Flower8},
]