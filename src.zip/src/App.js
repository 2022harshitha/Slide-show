// import logo from './logo.svg';
import './App.css';
import Slides from './Components/Slides';


function App() {
  return (
    <div className="App">
      Hello Everyone
      <Slides />
      
    </div>
  );
}

export default App;
